import { Fragment, useEffect, useRef } from 'react'
import prod from '../assets/produto.webp'
import { Particles } from './ui'
import { clamp, isStatic, sv } from '../lib/util'

const VIDEO = 'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260328_083109_283f3553-e28f-428b-a723-d639c617eb2b.mp4'
const HEAD: [string, boolean][] = [['Do mato ', false], ['jogado fora,', true], [' nasce ', false], ['o que limpa a terra.', true]]

export default function Hero() {
  const vref = useRef<HTMLVideoElement>(null)

  // Vídeo de fundo: loop manual com fade de 0,5 s na entrada e na saída
  useEffect(() => {
    const v = vref.current!
    if (isStatic()) return
    v.src = VIDEO
    let lo = -1, id = 0
    const loop = () => {
      if (scrollY > innerHeight * .9) { if (!v.paused) v.pause() } else if (v.paused && !v.ended) v.play().catch(() => {})
      const d = v.duration, t = v.currentTime
      let o = 1
      if (d) { if (t < .5) o = t / .5; else if (d - t < .5) o = (d - t) / .5 }
      o = clamp(+o.toFixed(3))
      if (o !== lo) { lo = o; v.style.opacity = String(o) }
      id = requestAnimationFrame(loop)
    }
    const ended = () => { v.style.opacity = '0'; lo = 0; setTimeout(() => { v.currentTime = 0; v.play().catch(() => {}) }, 100) }
    v.addEventListener('ended', ended); v.play().catch(() => {}); id = requestAnimationFrame(loop)
    return () => { v.removeEventListener('ended', ended); cancelAnimationFrame(id) }
  }, [])

  let k = 0
  return (
    <header className="hero2">
      <div className="vid" aria-hidden="true"><video ref={vref} muted playsInline preload="auto" tabIndex={-1} /></div>
      <Particles />
      <div className="hc">
        <span className="chip animate-fade-rise" style={{ background: 'rgba(255,255,255,.5)', color: '#4E6B5A', marginBottom: 28 }}>Biomassa que limpa a terra</span>
        <h1 className="font-display text-5xl sm:text-7xl md:text-8xl max-w-7xl font-normal" style={{ lineHeight: .95, letterSpacing: '-2.46px' }}>
          {HEAD.map(([t, em], i) => {
            const inner = t.split(/(\s+)/).map((w, j) => w.trim() ? <span key={j} className="wd" style={sv({ '--w': k++ })}>{w}</span> : w)
            return em ? <em key={i}>{inner}</em> : <Fragment key={i}>{inner}</Fragment>
          })}
        </h1>
        <p className="animate-fade-rise text-base sm:text-lg max-w-2xl mt-8 leading-relaxed text-moss" style={{ animationDelay: '.9s' }}>
          Cápsulas de biomassa de carrapicho e capim-caninha, para empresas ambientais encurtarem a vida útil de plástico, vidro e borracha.
        </p>
        <div className="hbtns animate-fade-rise" style={{ animationDelay: '1.1s' }}>
          <a className="btn lg sh mag" href="#/contato">Pedir proposta</a>
          <a className="btn lg lt" href="#/jornada">Ver a jornada da cápsula</a>
        </div>
      </div>
      <div className="hcap"><div className="glow" /><img src={prod} alt="Cápsula EcoVitality com a folha da marca" width={300} height={300} /></div>
    </header>
  )
}
