import { useEffect, useRef } from 'react'
import { LOGO } from '../lib/logo'
import { SLOGAN } from '../lib/copy'
import { Shader } from './Fx'
import { sv } from '../lib/util'

/* Final de página: a folha se encaixa, as letras sobem uma a uma, um brilho cruza a logo e o slogan se revela.
   Toca quando o bloco entra na tela e volta a tocar se a pessoa sair e voltar. */
export default function Finale() {
  const el = useRef<HTMLElement>(null)
  useEffect(() => {
    const e = el.current!
    const io = new IntersectionObserver(([x]) => {
      if (x.intersectionRatio >= .4) e.classList.add('go'); else if (!x.isIntersecting) e.classList.remove('go')
    }, { threshold: [0, .4] })
    io.observe(e)
    return () => io.disconnect()
  }, [])
  const word = (t: string, o: number, cls = '') => t.split(' ').map((w, k) => <span key={k}><span className={'fx fw ' + cls} style={sv({ '--w': o + k })}>{w}</span>{' '}</span>)
  return (
    <section className="fin" ref={el} aria-label="EcoVitality. A natureza renova. A ciência transforma.">
      <div className="fin-bg" aria-hidden="true"><Shader /></div>
      <div className="fin-in">
        <svg className="fin-logo" viewBox={`0 0 ${LOGO.w} ${LOGO.h}`} aria-hidden="true">
          <defs>
            <clipPath id="fcl">{[...LOGO.leaf, ...LOGO.word].map((p, k) => <path key={k} d={p.d} fillRule="evenodd" />)}</clipPath>
            <linearGradient id="fsw" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stopColor="#fff" stopOpacity="0" /><stop offset=".5" stopColor="#fff" stopOpacity=".95" /><stop offset="1" stopColor="#fff" stopOpacity="0" /></linearGradient>
          </defs>
          <g className="fglow"><ellipse cx="55" cy="72" rx="150" ry="110" fill="#7DC592" /></g>
          <path className="fx fl d" d={LOGO.leaf[0].d} fillRule="evenodd" fill="#2B8A5C" />
          <path className="fx fl l" d={LOGO.leaf[1].d} fillRule="evenodd" fill="#7DC592" />
          {LOGO.word.map((p, k) => <path key={k} className="fx fz" d={p.d} fillRule="evenodd" fill={p.k === 'eco' ? '#7DC592' : '#EAF5EE'} style={sv({ '--k': k })} />)}
          <g clipPath="url(#fcl)"><rect className="fsweep" x="-260" y="-20" width="260" height={LOGO.h + 40} fill="url(#fsw)" /></g>
        </svg>
        <p className="fin-s">
          <span className="ln">{word(SLOGAN[0], 0)}</span>
          <span className="ln em">{word(SLOGAN[1], 3, 'e')}</span>
        </p>
        <div className="fin-b fx">
          <a className="btn w mag" href="#/contato">Pedir proposta</a>
          <button type="button" className="btn g" onClick={() => scrollTo({ top: 0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' })}>Voltar ao topo</button>
        </div>
      </div>
    </section>
  )
}
