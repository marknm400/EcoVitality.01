/* Textos e dados enviados pelo cliente. Para trocar o nome da linha de produtos nos textos, altere só MARCA. */
export const MARCA = 'EcoVitalis'
export const SLOGAN: [string, string] = ['A natureza renova.', 'A ciência transforma.']

/* Uma pesquisa por card do processo, na ordem 1 a 5. t = título, p = texto, c = a conexão com a marca */
export const PESQUISA: { t: string; p: string; c: string }[] = [
  { t: 'Por que alguns resíduos persistem por tanto tempo?',
    p: 'Plástico, vidro e borracha apresentam características que dificultam sua degradação natural. Enquanto alguns materiais podem se fragmentar pela ação do sol e do desgaste ambiental, outros permanecem por longos períodos. No caso dos plásticos, essa fragmentação pode gerar microplásticos, sem eliminar necessariamente o impacto ambiental.',
    c: 'desenvolver alternativas que reduzam a persistência dos resíduos sem gerar novos riscos ambientais.' },
  { t: 'Quando o descarte se transforma em recurso',
    p: 'A biomassa vegetal, formada por folhas, caules e outros resíduos de plantas, pode ser aproveitada como matéria-prima para diferentes processos biotecnológicos. Essa prática está relacionada à economia circular, que busca reduzir desperdícios e valorizar recursos antes descartados.',
    c: 'aproveitar o carrapicho (Xanthium cavanillesii) e o capim-caninha (Andropogon lateralis) como fontes de biomassa para pesquisar novas soluções ambientais.' },
  { t: 'É possível acelerar a degradação dos materiais?',
    p: 'Enzimas são moléculas capazes de acelerar reações químicas. Pesquisas já demonstraram que determinadas enzimas podem degradar plásticos específicos, como o PET. Entretanto, cada material possui características próprias: uma solução que funciona para um tipo de plástico não necessariamente funciona para outros polímeros, borrachas ou vidro.',
    c: 'desenvolver uma formulação de origem vegetal cuja capacidade de degradar resíduos seja investigada e comprovada cientificamente.' },
  { t: 'Da hipótese à aplicação ambiental',
    p: 'Antes de utilizar uma nova tecnologia na natureza, é necessário verificar sua eficácia e segurança. Testes controlados permitem avaliar a transformação dos materiais, identificar os resíduos resultantes e investigar possíveis efeitos sobre o solo, a água e os organismos vivos.',
    c: 'o sistema de cápsula e pulverizador representa uma proposta de aplicação que precisaria passar por testes de eficiência e segurança antes de ser utilizado em ambientes reais.' },
  { t: 'Degradar não significa necessariamente eliminar',
    p: 'A degradação de um material pode gerar substâncias menores sem eliminar completamente seus impactos. Plásticos podem originar microplásticos, enquanto vidro e borracha apresentam desafios diferentes de transformação. Por isso, é importante avaliar não apenas a redução dos resíduos, mas também os produtos resultantes do processo.',
    c: 'buscar uma solução que reduza a persistência dos poluentes sem transferir a contaminação para o solo ou para a água.' },
]

/* Cartões da seção "Do descarte à inovação ambiental." */
export const WHY: { n: string; t: string; s: string; p: string; tags: string[] }[] = [
  { n: '01', t: 'Economia circular na prática', s: 'De resíduo vegetal a recurso produtivo.', p: 'Em vez de depender exclusivamente de matérias-primas convencionais, a proposta busca valorizar a biomassa proveniente do manejo da vegetação, conectando o aproveitamento de resíduos à inovação ambiental.', tags: ['Reaproveitamento', 'Economia circular'] },
  { n: '02', t: 'Uma solução orientada pela ciência', s: 'Inovação exige evidências.', p: 'Cada material apresenta características próprias. Por isso, uma tecnologia ambiental precisa ser testada para identificar sua eficácia, seus limites e os possíveis impactos dos produtos resultantes.', tags: ['Pesquisa', 'Validação científica'] },
  { n: '03', t: 'Além da aparência limpa', s: 'O que acontece depois da degradação?', p: 'Reduzir o tamanho de um resíduo não significa eliminá-lo. Uma solução realmente responsável precisa considerar os subprodutos do processo e evitar a transferência da contaminação para o solo e a água.', tags: ['Segurança ambiental', 'Monitoramento'] },
  { n: '04', t: 'O futuro que queremos construir', s: 'Uma nova perspectiva para o manejo de resíduos.', p: `A ${MARCA} propõe aproximar o aproveitamento de biomassa, a pesquisa biotecnológica e a gestão de resíduos em um mesmo projeto, buscando caminhos para reduzir impactos ambientais por meio de soluções verificáveis.`, tags: ['Inovação sustentável', 'Visão de futuro'] },
]

/* Modalidades de compra. Valores em centavos; desconto e economia são calculados contra comprar o mesmo volume em cápsulas Pro de 1 litro. */
const BASE = 39990
export const MODS = ([['Pro', 1, 39990], ['Max', 5, 142990], ['Industrial', 10, 259990], ['Bulk', 20, 479990]] as [string, number, number][]).map(([nome, vol, cents]) => {
  const ref = BASE * vol, save = ref - cents
  return { nome, full: `${MARCA} ${nome}`, vol, vl: vol === 1 ? '1 litro' : `${vol} litros`, cents, perL: Math.round(cents / vol), pct: Math.round(save / ref * 100), save }
})
export const brl = (c: number) => 'R$ ' + (c / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
