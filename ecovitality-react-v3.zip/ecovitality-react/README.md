# EcoVitality (React + Vite + Tailwind + TypeScript)

    npm install
    npm run dev      # desenvolvimento (abra o endereço localhost mostrado)
    npm run build    # gera a pasta dist/

Páginas (roteamento por hash, sem dependência extra):
- `#/` Início: hero com vídeo, texto que se preenche, cartões numerados e cartões que empilham.
- `#/jornada` A jornada da cápsula (animação conceitual em scroll, em página própria).
- `#/produto` Preços em vidro, alternância por litro e tabela.
- `#/contato` Proposta, perguntas e formulário de demonstração (com confete).
- Qualquer outra rota mostra a página 404.

Visual v2 (vidro escuro premium, mais bruto):
- `src/styles/glass2.css`: camada nova de estilo. Vidro com luz nas bordas e brilho diagonal, grão fino, aurora de fundo, títulos grandes com degradê, botões com luz interna, cúpula com órbitas, marca gigante no rodapé. Para voltar ao visual anterior, remova o import dessa folha em `main.tsx`.
- `src/components/Fx.tsx`: efeitos novos do naocodei.com/free-code: galeria horizontal (02), máscara que revela (05), embaralhar letras (15), gráfico de barras (25) e fundo com shader WebGL (31).
- Início: galeria "Onde a cápsula trabalha", antes e depois com máscara circular e cúpula que leva à jornada. Rodapé com shader e marca gigante.
- Produto: gráfico de barras do preço por litro (usa os preços já existentes).
- Jornada (página própria): linha do tempo, anel de progresso e shader que acende conforme o solo se recupera.
- Em celular, tela vertical e movimento reduzido, tudo cai para versões estáticas (sem shader, galeria com rolagem lateral, máscara dividida ao meio).

Rodada v3:
- `src/lib/copy.ts`: todos os textos e preços enviados (pesquisas, cartões, modalidades). A constante `MARCA` troca o nome "EcoVitalis" em todos os textos de uma vez.
- `src/components/Expand.tsx`: card do processo que expande após 2 s de cursor (ou clique, toque e Enter), com a pesquisa em painel.
- `src/components/Finale.tsx` e `src/lib/logo.ts`: final de página com a logo vetorizada (folha e letras animadas) e o slogan.
- `src/styles/v3.css`: estilos novos. Produto agora tem 4 modalidades, tabela com desconto e gráfico de desconto por quantidade.

Arquivos principais: `src/components/Hero.tsx` (vídeo em loop com fade), `Journey.tsx` e `Scene.tsx` (jornada), `Global.tsx` (cursor, rolagem com inércia, luz e inclinação nos cartões, ímã e onda nos botões), `ui.tsx` (odômetro, partículas, confete), `src/styles/*`.
O vídeo vem da URL em `VIDEO`, no topo de Hero.tsx. O formulário é de demonstração e não envia dados.
